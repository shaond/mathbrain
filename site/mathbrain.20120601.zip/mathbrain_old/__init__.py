# -*- coding: utf-8 -*-

__about__ = """
This project takes the zero_project and adds basic account management
functionality such as sign up, log in, password change/reset and email
confirmation. It is a foundation suitable for most sites that have user
accounts.
"""
